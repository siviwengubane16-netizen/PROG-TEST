
package number1coffeehut;

public class BeverageReport {
  
    public static void main(String[] args) {
        // Single-dimensional array for cities
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        // Single array for beverage types
        String[] beverages = {"Coffee", "Tea", "Boba Tea"};

        // Two-dimensional array for sales data
        // Row = city, Column = beverage
        int[][] sales = {
            {500, 300, 125}, // Cape Town
            {450, 250, 100}, // Port Elizabeth
            {480, 175, 120} // Pretoria
        };

        int grandTotal = 0;

        System.out.println("=== NUMBER 1 COFFEE HUT BEVERAGE REPORT ===");
        System.out.println("-----------------------------------------------");
        System.out.printf("%-18s %-10s %-10s %-10s %-10s\n", "City", "Coffee", "Tea", "Boba Tea", "Total");
        System.out.println("-----------------------------------------------");

        for (int i = 0; i < cities.length; i++) {
            int cityTotal = 0;
            for (int j = 0; j < sales[i].length; j++) {
                cityTotal += sales[i][j];
            }
            grandTotal += cityTotal;

            System.out.printf("%-18s %-10d %-10d %-10d %-10d\n",
                cities[i], sales[i][0], sales[i][1], sales[i][2], cityTotal);
        }

        System.out.println("-----------------------------------------------");
        System.out.println("Total sales for all cities: " + grandTotal);
    }
}

