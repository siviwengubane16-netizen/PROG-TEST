
  public class BeverageSales extends Beverage {
    
    public BeverageSales(String beverageType, String city, int totalSales) {
        super(beverageType, city, totalSales);
    }

    public void printReport() {
        System.out.println("Beverage Type: " + getBeverageType());
        System.out.println("City: " + getCity());
        System.out.println("Total Sales: " + getTotalSales());
    }
}  

