
import java.util.Scanner;
public class RunApplication {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter beverage type: ");
        String type = input.nextLine();

        System.out.print("Enter city: ");
        String city = input.nextLine();

        System.out.print("Enter total sales: ");
        int sales = input.nextInt();

        BeverageSales mySale = new BeverageSales(type, city, sales);
        
        System.out.println("\n--- REPORT ---");
        mySale.printReport();
    }
}  

